<?php

namespace XF\Api;

class Templater extends \XF\Template\Templater
{
}